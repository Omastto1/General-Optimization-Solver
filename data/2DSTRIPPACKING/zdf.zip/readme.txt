The format of each of these data files is:
number n of items
width W for the strip 
for each item i (i=0,...,n-1): 
  index i, width of item i, height of item i